# MyFirstWebProject

We are working on Python & Django Project.

Let's develop a web application with the help of Python with Django webframwork.

Integration with Jenkins
